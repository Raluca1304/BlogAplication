
import React from 'react';

export function Gallery() {
  return (
    <div className="w3-row-padding">
      <div className="w3-third w3-container w3-margin-bottom">
        <img src="https://www.w3schools.com/w3images/mountains.jpg" alt="Norway" style={{ width: "100%" }} className="w3-hover-opacity" />
        <div className="w3-container w3-white">
          <p><b>Lorem Ipsum</b></p>
          <p>Praesent tincidunt sed tellus ut rutrum.</p>
        </div>
      </div>
      {/* ... alte imagini la fel ... */}
    </div>
  );
}
