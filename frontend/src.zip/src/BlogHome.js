export function BlogHome() {
  return (
    <div className="page">
      <header className="header">
        <div className="left">Out & About</div>
        <div className="center">Raluca Nica</div>
        <div className="right">
          <span>All Posts</span>
          <div className="icons">
            <i className="fa fa-facebook"></i>
            <i className="fa fa-instagram"></i>
            <i className="fa fa-twitter"></i>
          </div>
        </div>
      </header>

      <main className="main">
        <div className="title-section">
          <h1>These are few of my favorite things.</h1>
          <a className="read-more" href="#">Read It All →</a>
        </div>

        <div className="grid">
          <div className="left-box">
            <p style={{ color: "#999" }}>Aug 14, 2024 • 2 min read</p>
            <div className="placeholder-article">Best Weekend Getaways Near You</div>
          </div>

          <div className="right-box">
            <h3>Here's me 👋🍂</h3>
            <p>This is the space to introduce the business and what it has to offer. Define the qualities and values that make it unique.</p>
            <hr />
            <h4>Popular Tags</h4>
            <p>No tags yet.</p>
          </div>
        </div>
      </main>
    </div>
  );
}
