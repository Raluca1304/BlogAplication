import React, { useState, useEffect } from 'react'
import { BrowserRouter, Routes, Route, useParams, Navigate, NavLink, useNavigate } from "react-router";
import { Layout } from './Layout';
import { BlogHome } from './BlogHome';


export function BlogApp() {
  return (
    <BrowserRouter>
        <Routes>
            <Route path="/" element={<Layout />}>
            <Route path="/" element={<BlogHome />} />
            <Route index element={<Navigate to="/login" />} />
            <Route path="login" element={<Login />} />
            <Route path="posts" element={<Posts />} />
            <Route path="posts/:id" element={<PostItem />} />
            
            </Route>
        </Routes>
    </BrowserRouter>
  );
}
 
export function Posts() {
    const [articles, setArticles] = useState([]);
 
    useEffect(() => {
        fetch("/api/articles")
            .then(response => response.json())
            .then((data) => {
                console.log(data)
                setArticles(data);
            })
            .catch((err) => console.error("Eroare la fetch:", err));
    }, []);
 
    return (
    <div className="articles">
      {articles.map((article) => (
        <div className="article" key={article.id}>
          <NavLink to={`/posts/${article.id}`} className="title">
            {article.title}
          </NavLink>
          <div className="sum">{article.summary}</div>
        </div>
      ))}
    </div>
  );
}

export function PostItem() {
  const { id } = useParams();
  const [article, setArticle] = useState(null);

  useEffect(() => {
    fetch(`/api/articles/${id}`)
      .then((res) => res.json())
      .then((data) => setArticle(data))
      .catch((err) => console.error("Eroare la fetch:", err));
  }, [id]);

  if (!article) return <p>Loading...</p>;

  return (
    <div className="article">
      <h2>{article.title}</h2>
      <p>{article.content}</p>
       <NavLink to={`/posts/${article.id}/${article.author}`} className="author">
            {article.author}
          </NavLink>
      <p>
        <small>{new Date(article.createdDate).toLocaleString()}</small>
      </p>
    </div>
  );
}


export function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [token, setToken] = useState(null);
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const res = await fetch('/api/users/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
      });

      const data = await res.json();
      if (data.token) {
        setToken(data.token);
        localStorage.setItem('jwt', data.token);
        navigate('/posts');
      } else {
        alert("Wrong username or password!");
      }
    } catch (err) {
      console.error("Eroare la fetch:", err);
    }
  };

  return (
    <div className="Login">
      <h2>Login</h2>
      <input
        type="text"
        placeholder="username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <input
        type="password"
        placeholder="parola"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button onClick={handleLogin}>Login</button>

      {token && <p>Tokenul este: {token}</p>}
    </div>
  );
}



