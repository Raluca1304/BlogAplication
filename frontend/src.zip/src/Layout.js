import { Outlet, NavLink, useLocation, useParams } from 'react-router';

export function Layout() {
  const location = useLocation();
  const params = useParams();
  const isLoggedIn = !!localStorage.getItem('jwt');

  const isLoginPage = location.pathname === "/login";
  const isOnPostDetail = location.pathname.startsWith("/posts/") && params.id;

  const logout = () => {
    localStorage.removeItem('jwt');
    window.location.href = '/login';
  };

  return (
    <div>
      <header>
        <h1>Blog App</h1>

        {isOnPostDetail && (
          <NavLink to="/posts" className="home-link">🏠 Home</NavLink>
        )}

        {!isLoginPage && isLoggedIn && (
          <button onClick={logout}>Logout</button>
        )}
      </header>

      <main>
        <Outlet />
      </main>
    </div>
  );
}
